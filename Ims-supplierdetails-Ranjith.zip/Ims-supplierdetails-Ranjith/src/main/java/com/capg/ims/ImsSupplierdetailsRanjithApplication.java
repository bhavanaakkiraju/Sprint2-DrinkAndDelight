package com.capg.ims;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImsSupplierdetailsRanjithApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImsSupplierdetailsRanjithApplication.class, args);
	}

}
