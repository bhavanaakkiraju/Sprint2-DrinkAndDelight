package com.capg.im;
//import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.capg.im.entity.RawMaterialBean;
import com.capg.im.service.TrackOrderServiceImpl;
import java.util.List;
@RunWith(SpringRunner.class)
@SpringBootTest
class InventoryManagementApplicationTests {
 @Autowired
 TrackOrderServiceImpl trackorderserviceimpl;
	@Test
	void getAllRawMaterials() {
		List<RawMaterialBean> bean = trackorderserviceimpl.getAll();
		assertEquals(bean.size(),2);
	} 

}
