package com.capg.im.dao;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.History;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.History;
//import com.capg.bank.entity.BankBean;
import com.capg.im.entity.RawMaterialBean;
@Repository
@Transactional
public class TrackOrderDaoImpl implements ITrackOrderDao{
	@PersistenceContext
	EntityManager em;
	/** @author pavithra :
	 * This insertRawMaterials method will 
	 * insert details into the entity of rawmaterialbean **/
	@Override
	public RawMaterialBean insertRawMaterials(RawMaterialBean bean) {
			 em.persist(bean);
		 	 return bean;
		 }
	/** @author pavithra :
	 * This getRawMaterials method will
	 *  retrieve the details(object) of rawmaterials present 
	 * in particular id
	 **/
	@Override
	public RawMaterialBean getRawMaterials(int id) {
				return em.find(RawMaterialBean.class, id);
	}
	@Override
	public List<RawMaterialBean> getAll() {
		TypedQuery<RawMaterialBean> query = em.createQuery("from RawMaterialBean", RawMaterialBean.class);
		return query.getResultList();
	}
	
	/*
	 * @Override public RawMaterialBean setDate(int id,Date processingdate) {
	 * RawMaterialBean bean = em.find(RawMaterialBean.class, id);
	 * bean.setProcessingDate(bean.getProcessingDate()); System.out.println(bean);
	 * em.persist(bean);
	 * return bean;
	 */
//}
		//History history = new History("FundTransfer To "+id2, id1, amount);
		
		//em.persist(history);
		//BankBean bean1 = em.find(BankBean.class, id2);
		//bean1.setAmount(bean1.getAmount()+amount);
		//System.out.println(bean1);
		//em.persist(bean1);
		
		
//		History history1 = new History("FundTransfer From "+id1, id2, amount);
		
	//	em.persist(history1);
		
		
	}

