package com.capg.im;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import com.capg.im.dao.ITrackOrderDao;
import com.capg.im.entity.RawMaterialBean;
import com.capg.im.service.ITrackOrderService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class InventoryManagementApplicationTests1 {
	@Autowired
	private ITrackOrderService trackorderservice;
	@MockBean
	private ITrackOrderDao trackorderdao;

	@Test
	public void rawmaterial() {
		RawMaterialBean rawmaterialbean = new RawMaterialBean();
		rawmaterialbean.setOrderId(162);
		rawmaterialbean.setName("soda water");
		rawmaterialbean.setQuantityValue(10);
		rawmaterialbean.setQuantityUnit("a");
		rawmaterialbean.setPricePerUnit(20);
		rawmaterialbean.setTotalPrice(2);
		rawmaterialbean.setWareouseId("pound");
		Mockito.when(trackorderdao.insertRawMaterials(rawmaterialbean)).thenReturn(rawmaterialbean);
		assertThat(trackorderservice.insertRawMaterials(rawmaterialbean)).isEqualTo(rawmaterialbean);
	}

	@Test
	public void testgetAllRawMaterials() {
		RawMaterialBean rawmaterialbean1 = new RawMaterialBean();
		rawmaterialbean1.setOrderId(162);
		rawmaterialbean1.setName("soda water");
		rawmaterialbean1.setQuantityValue(10);
		rawmaterialbean1.setQuantityUnit("a");
		rawmaterialbean1.setPricePerUnit(20);
		rawmaterialbean1.setTotalPrice(2);
		rawmaterialbean1.setWareouseId("pound");

		RawMaterialBean rawmaterialbean2 = new RawMaterialBean();

		rawmaterialbean2.setOrderId(181);
		rawmaterialbean2.setName("paste");
		rawmaterialbean2.setQuantityValue(45);
		rawmaterialbean2.setQuantityUnit("hkjg");
		rawmaterialbean2.setPricePerUnit(40);
		rawmaterialbean2.setTotalPrice(400);
		rawmaterialbean2.setWareouseId("kgfee");

		List<RawMaterialBean> viewlist = new ArrayList();
		viewlist.add(rawmaterialbean1);
		viewlist.add(rawmaterialbean2);
		Mockito.when(trackorderdao.getAll()).thenReturn(viewlist);
		assertThat(trackorderservice.getAll()).isEqualTo(viewlist);
		assertEquals(viewlist.size(), 7);
	}
}
