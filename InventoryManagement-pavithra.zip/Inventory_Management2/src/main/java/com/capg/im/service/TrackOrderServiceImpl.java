package com.capg.im.service;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capg.im.dao.ITrackOrderDao;
import com.capg.im.entity.RawMaterialBean;

@Service
public class TrackOrderServiceImpl implements ITrackOrderService {
	@Autowired
	ITrackOrderDao dao;

	/**
	 * @author pavithra : This insertRawMaterials method will insert details into
	 *         the entity
	 **/
	@Override
	public RawMaterialBean insertRawMaterials(RawMaterialBean bean) {
		return dao.insertRawMaterials(bean);
	}

	/**
	 * @author pavithra : This getAll method will retrieve the details(object) of
	 *         rawmaterials present
	 * 
	 **/

	@Override
	public List<RawMaterialBean> getAll() {
		// TODO Auto-generated method stub
		return dao.getAll();
	}

	/**
	 * @author pavithra : This deleteRawMaterials method will delete the
	 *         details(object) of rawmaterials present in database
	 **/
	@Override
	public RawMaterialBean deleteRawMaterials(int id) {
		// TODO Auto-generated method stub
		return dao.deleteRawMaterials(id);
	}

}