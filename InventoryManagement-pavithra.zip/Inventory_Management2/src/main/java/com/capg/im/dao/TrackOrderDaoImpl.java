package com.capg.im.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.capg.im.entity.RawMaterialBean;

@Repository
@Transactional
public class TrackOrderDaoImpl implements ITrackOrderDao {
	@PersistenceContext
	EntityManager em;

	/**
	 * @author pavithra : This insertRawMaterials method will insert details into
	 *         the entity of rawmaterialbean
	 **/
	@Override
	public RawMaterialBean insertRawMaterials(RawMaterialBean bean) {
		em.persist(bean);
		return bean;
	}

	/**
	 * @author pavithra : This getAll method will retrieve the details(object) of
	 *         rawmaterials present database
	 **/

	@Override
	public List<RawMaterialBean> getAll() {
		TypedQuery<RawMaterialBean> query = em.createQuery("from RawMaterialBean", RawMaterialBean.class);
		return query.getResultList();
	}

	/**
	 * @author pavithra : This deleteRawMaterials method will delete the
	 *         details(object) of rawmaterials present in database
	 **/
	@Override
	public RawMaterialBean deleteRawMaterials(int id) {
		RawMaterialBean bean = em.find(RawMaterialBean.class, id);
		em.remove(bean);
		return bean;
	}

}
