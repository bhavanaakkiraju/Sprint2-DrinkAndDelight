package com.capg.im.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RawMaterials_Spring")
public class RawMaterialBean {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int orderId;
	private String name;

	private double quantityValue;
	private String quantityUnit;

	private double pricePerUnit;
	private double totalPrice;
	String wareouseId;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getQuantityValue() {
		return quantityValue;
	}

	public void setQuantityValue(double quantityValue) {
		this.quantityValue = quantityValue;
	}

	public String getQuantityUnit() {
		return quantityUnit;
	}

	public void setQuantityUnit(String quantityUnit) {
		this.quantityUnit = quantityUnit;
	}

	public double getPricePerUnit() {
		return pricePerUnit;
	}

	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getWareouseId() {
		return wareouseId;
	}

	public void setWareouseId(String wareouseId) {
		this.wareouseId = wareouseId;
	}

	@Override
	public String toString() {
		return "RawMaterialOrder OrderId=" + orderId + "\n" + " Name=" + name + "\n" + "QuantityValue=" + quantityValue
				+ "\n" + " QuantityUnit=" + quantityUnit + "\n" + " PricePerUnit=" + pricePerUnit + "\n" + "TotalPrice="
				+ totalPrice + "\n" + " WareouseId=" + wareouseId;
	}

}
