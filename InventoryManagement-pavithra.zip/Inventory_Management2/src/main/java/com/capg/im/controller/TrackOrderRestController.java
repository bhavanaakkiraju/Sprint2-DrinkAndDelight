package com.capg.im.controller;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.im.entity.RawMaterialBean;

import com.capg.im.service.TrackOrderServiceImpl;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class TrackOrderRestController {
	@Autowired
	TrackOrderServiceImpl tsi;

	@PostMapping("/rawmaterial/insert")
	/**
	 * @author pavithra : This insertRawMaterials method will insert details into
	 *         the entity of rawmaterialbean
	 **/
	public String insertRawMaterials(@RequestBody RawMaterialBean bean) {
		RawMaterialBean rawmaterialbean = tsi.insertRawMaterials(bean);
		return "Hello " + rawmaterialbean.getName() + rawmaterialbean.getPricePerUnit()
				+ rawmaterialbean.getQuantityUnit() + "\n Your Insertion is Successfull\n" + "Your Account Id is "
				+ rawmaterialbean.getOrderId();
	}

	/**
	 * @author pavithra : This getall method will retrieve the details(object) of
	 *         rawmaterials present in data-base
	 **/

	@GetMapping("/rawmaterial/findall") // GET: http://localhost:8090/bank/findall
	public List<RawMaterialBean> getall() {

		List<RawMaterialBean> bean = tsi.getAll();
		return bean;
	}

	/**
	 * @author pavithra : This deleteRawMaterials method will delete the
	 *         details(object) of rawmaterials present in data-base
	 **/
	@DeleteMapping("/rawmaterial/delete/{id}")
	public String deleteRawMaterials(@PathVariable int id) throws Exception {
		RawMaterialBean rawmaterialbean = tsi.deleteRawMaterials(id);
		if (rawmaterialbean == null) {
			throw new Exception("Invalid id");
		}
		return "Hello " + "\n your Account has been deleted successfully\n" + " of id:" + rawmaterialbean.getOrderId();
	}

	@ExceptionHandler(Exception.class)
	public String inValid(Exception e) {
		return e.getMessage();
	}

}
